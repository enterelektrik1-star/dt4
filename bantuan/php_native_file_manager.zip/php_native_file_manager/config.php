<?php
// Konfigurasi File Manager. WAJIB ganti password sebelum dipasang online.
define('APP_NAME', 'Web File Manager');
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'GantiPasswordKuat123!'); // Ganti dengan password Anda.
define('STORAGE_PATH', __DIR__ . '/storage');
define('MAX_UPLOAD_BYTES', 50 * 1024 * 1024); // 50 MB
